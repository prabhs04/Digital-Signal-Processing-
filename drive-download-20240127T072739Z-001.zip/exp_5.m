%% hamming window
clc
clear all 
m = 25;
t = 0.1:1:m-1;
ah = 0.54-0.46*cos((2.*pi.*t)./(m-1));
figure
subplot(1,2,1)
stem(t,ah)
xlabel('time')
ylabel('amplitude')
title('time response of hamming window')
legend('muskan,102106031')

[h,w]=freqz(ah,1,2048);
wn = w./(2*pi);
hn = abs(h)./max(abs(h));
hd = conv(hn,wn);
m = length(wn);
n = length(hd);
w1 = zeros(1,n-m);
wd = [wn,w1];
subplot(1,2,2)
plot(wd,hd)
xlabel('frequency')
ylabel('amplitude')
title('frequency response of hamming window')
legend('muskan,102106031')