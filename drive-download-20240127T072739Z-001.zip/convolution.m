function p = convolution(x,y,z)
    p = zeros(1,z);
    for i = 1:z
        for j = 1:z
            if(i-j+1>0)
                p(i)=p(i)+x(j)*y(i-j+1);
            end
        end
    end
end
