%% low pass filter
% Load the input image
inputImage = imread('input_image.jpg');

% Separate color channels (assuming RGB image)
R = inputImage(:, :, 1);
G = inputImage(:, :, 2);
B = inputImage(:, :, 3);

% Define the filter kernel (low-pass filter for smoothing)
filterSize = 1;  % Kernel size (e.g., 5x5)
filterCoeff = ones(filterSize) / (filterSize^2);  % Averaging filter coefficients

% Apply the FIR filter using convolution for each channel
outputR = conv2(double(R), filterCoeff, 'same');
outputG = conv2(double(G), filterCoeff, 'same');
outputB = conv2(double(B), filterCoeff, 'same');

% Combine the enhanced channels back into an RGB image
outputImage = cat(3, uint8(outputR), uint8(outputG), uint8(outputB));

% Display the original and enhanced images
figure
subplot(1, 2, 1);
imshow(inputImage);
title('Original Image');

subplot(1, 2, 2);
imshow(outputImage);
title('Enhanced Image (Low-Pass Filter)');

% Save the enhanced image
%imwrite(outputImage, 'enhanced_image.jpg');

% Optional: You can further customize the filter coefficients and filter types for specific enhancement effects.
%% high pass filter
% Load the input image
inputImage = imread('input_image.jpg');

% Separate color channels (assuming RGB image)
R = inputImage(:, :, 1);
G = inputImage(:, :, 2);
B = inputImage(:, :, 3);

% Define the filter kernel (high-pass filter)
filterSize =50;  % Kernel size (e.g., 3x3)
centerValue = -1;
filterCoeff = ones(filterSize) * centerValue;
filterCoeff(floor(filterSize/2)+1, floor(filterSize/2)+1) = filterSize^2 - 1;

% Normalize the filter so that its sum is zero
filterCoeff = filterCoeff - mean(filterCoeff(:));

% Apply the FIR filter using convolution for each channel
outputR = conv2(double(R), filterCoeff, 'same');
outputG = conv2(double(G), filterCoeff, 'same');
outputB = conv2(double(B), filterCoeff, 'same');

% Combine the enhanced channels back into an RGB image
outputImage = cat(3, uint8(outputR), uint8(outputG), uint8(outputB));

% Display the original and enhanced images
figure
subplot(1, 2, 1);
imshow(inputImage);
title('Original Image');

subplot(1, 2, 2);
imshow(outputImage);
title('Enhanced Image (High-Pass Filter)');

% Save the enhanced image
%imwrite(outputImage, 'enhanced_image.jpg');
