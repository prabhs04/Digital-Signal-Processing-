clc
clear all
% Sample EEG data (replace with real data)
fs = 1000; % Sampling frequency (Hz)
t = 0:1/fs:10; % Time vector
eeg_data = sin(2*pi*10*t) + 0.5*randn(size(t)); % Simulated EEG with noise
% Filter design parameters
order = 4; % Filter order
cutoff_freq = 50; % Cutoff frequency in Hz
% Design the IIR Butterworth filter
[b, a] = butter(order, cutoff_freq / (fs/2), 'low');
% Create a filter object for real-time processing
butter_filter = dsp.IIRFilter('Numerator', b, 'Denominator', a);
% Initialize filtered EEG data
filtered_eeg = zeros(size(eeg_data));
% Real-time filtering
for i = 1:length(eeg_data)
filtered_eeg(i) = step(butter_filter, eeg_data(i));
end
% Plot the original EEG and filtered EEG
figure;
subplot(2,1,1);
plot(t, eeg_data);
title('Original EEG');
xlabel('Time (s)');
subplot(2,1,2);
plot(t, filtered_eeg);
title('Filtered EEG');
xlabel('Time (s)');
