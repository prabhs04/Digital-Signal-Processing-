function x = length1(m,n)
    x = m+n-1;
end