function[z]= seqIDFT(X)
N= length(X);
z= zeros(N,1);
for k= 0:N-1
    for n= 0:N-1
        z(k+1)= z(k+1)+X(n+1)*exp((j*2*pi*n*k)/N)
    end
    z(k+1)= (1/N)*z(k+1);
end
end