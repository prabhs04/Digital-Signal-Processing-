%% lab 1a to generate unit impluse(discrete and cont) and signum
%% unit impulse cont
clc
clear all
t = -5:0.01:5;
impulse = t==0;
figure
subplot(1,2,1)
plot(t,impulse)
xlabel('t')
ylabel('X(t)')
legend('muskan,102106031')
title('continous impulse signal')
grid on
%% unit impulse discrete
n = -5:1:5;
imp_discrete = n==0;
subplot(1,2,2)
stem(n,imp_discrete)
xlabel('n')
ylabel('X[n]')
legend('muskan,102106031')
title('discrete impulse signal')
grid on
%% signum function 
n = -10:1:10;
x_n1 = n>=0;
x_n2 = n<=0;
sgn_n = x_n1-x_n2;
figure
stem(n,sgn_n);
xlabel('n')
ylabel('sgn[n]')
legend('muskan,102106031')
title('Signum function')
grid on

