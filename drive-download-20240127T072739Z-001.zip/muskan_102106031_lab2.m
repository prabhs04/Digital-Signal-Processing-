%  WAP to find linear convolution
clc
clear all 
x = input('input seq1');
y = input('input seq2');
m = length(x);
n = length(y);
z = length1(m,n)
x = [x,zeros(1,z-m)];
y = [y,zeros(1,z-n)];
p = zeros(1,z);
p = convolution(x,y,z)
stem(p)
grid on 

xlabel('n')
ylabel('p(n)')
title('linear conv')
legend('muskan,102106031')


