clc
clear all
%% rectangular window
wp=0.2*pi;
ws=.3*pi;    
wc=(ws+wp)/2;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
dw=(ws-wp);
%M1=ceil(1.8*pi/dw)+1;
M=49;
n=linspace(0,M-1,M);
hd=zeros(1,length(n));
hd=sin(wc.*(n-((M-1)/2)))./((pi.*(n-((M-1)/2))));
hd(1,((M-1)/2)+1)=(wc/pi);
WI=ones(1,length(n));
h=hd.*WI;
[H,w]=freqz(h,1,1024);
wN=(w./(2*pi));
HN=abs(H)./max(abs(H));
figure
plot(wN,(20.*log10(HN)),'r');
grid
xlabel('\bf Normalised Frequency ----->')
ylabel('\bf Magnitude Spectrum (dB)---->')
title('\bf Lowpass Filter Designed with Rectangular Window Function')
legend('muskan,102106031')
%% triangular window
wp=0.2*pi;
ws=.3*pi;
wc=(ws+wp)/2;
dw=(ws-wp);
M1=ceil(1.8*pi/dw)+1;
M=49;
n=linspace(0,M-1,M);
hd=zeros(1,length(n));
hd=sin(wc.*(n-((M-1)/2)))./((pi.*(n-((M-1)/2))));
hd(1,((M-1)/2)+1)=(wc/pi);
%WI=0.54-0.46*cos((2.*pi.*n)./M);
WI=1-abs((n-(M-1)/2)./((M-1)/2));
h=hd.*WI;
[H,w]=freqz(h,1,1024);
wN=(w./(2*pi));
HN=abs(H)./max(abs(H));
figure
plot(wN,(20.*log10(HN)),'r');
grid
xlabel('\bf Normalised Frequency ----->')
ylabel('\bf Magnitude Spectrum (dB)---->')
title('\bf Lowpass Filter Designed with triangular Window Function')
legend('muskan,102106031')