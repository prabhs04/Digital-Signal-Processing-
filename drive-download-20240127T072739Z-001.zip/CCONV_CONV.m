
clc
clear all
X=[1,2,3,7];
Y=[4,5,6,5,10];
m = length(X);
n = length(Y);
p = m+n-1;
q=max(m,n);
Z=zeros(q);
Z=cconv(X,Y)
M = zeros(p);
M=conv(X,Y)