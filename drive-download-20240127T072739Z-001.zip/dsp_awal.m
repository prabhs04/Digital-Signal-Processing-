clc
clear all
% Define the filter coefficients for equalization
% Example: A low-pass filter
Fs = 44100; % Sample rate (Hz)
Fc = 1000;  % Cutoff frequency (Hz)
N = 100;    % Filter order
h = fir1(N, Fc / (Fs / 2));

% Read the input audio file
[inputAudio, Fs] = audioread('Input_audio.wav');

% Apply equalization to the input audio
outputAudio = filter(h, 1, inputAudio);

% Play the equalized audio
sound(outputAudio, Fs);

disp("The code is being successfully implemented!")
