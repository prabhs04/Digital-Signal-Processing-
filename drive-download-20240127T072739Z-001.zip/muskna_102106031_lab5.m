%
clc
clear
m=25;
t=0.1:m-1;
ah=0.54-0.46.*cos((2.*pi.*t)./(m-1));
figure
subplot(2,1,1)
stem(t,ah)
grid on
xlabel('n')
ylabel('Amplitude')
title('Hamming window with m=25')
legend('Muskan;102106031')
[h,w]=freqz(ah,1,1024);
wn=w./(2*pi);
hdn=abs(h)./max(abs(h));
hn=wn.*hdn;
subplot(2,1,2)
plot(wn,20.*log10(hn))
legend('Muskan;102106031')
grid
xlabel('f')
ylabel('Amplitude')
title('Frequency respnse of hamming window')
%%
clc
clear
m=25;
t=0.1:m-1;
ah=0.42-0.5.*cos((2.*pi.*t)./(m-1))+0.08.*cos((4.*pi.*t)./(m-1));
figure
subplot(2,1,1)
stem(t,ah)
grid on
xlabel('n')
ylabel('Amplitude')
title('Blackman window with m=25')
legend('Muskan;102106031')
[h,w]=freqz(ah,1,1024);
wn=w./(2*pi);
hdn=abs(h)./max(abs(h));
hn=wn.*hdn;
subplot(2,1,2)
plot(wn,20.*log10(hn))
legend('Muskan;102106031')
grid
xlabel('f')
ylabel('Amplitude')
title('Frequency respnse of blackman window')
%%
clc
clear
m=25;
t=0.1:m-1;
ah=0.5-0.5.*cos((2.*pi.*t)./(m-1));
figure
subplot(2,1,1)
stem(t,ah)
grid on
xlabel('n')
ylabel('Amplitude')
title('Hanning window with m=25')
legend('Muskan;102106031')
[h,w]=freqz(ah,1,1024);
wn=w./(2*pi);
hdn=abs(h)./max(abs(h));
hn=wn.*hdn;
subplot(2,1,2)
plot(wn,20.*log10(hn))
legend('Muskan;102106031')
grid
xlabel('f')
ylabel('Amplitude')
title('Frequency respnse of hanning window')