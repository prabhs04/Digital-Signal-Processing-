function [y,t]=dft1(x,N)
l=length(x);
if l<=N
    z=[x, zeros(1,N-l)];
    y=zeros(1,N);
    for k=0:N-1
        for n=0: (N-1)
            y(1,k+1) = y(1,k+1)+z(1,n+1)*exp((-1*1i*2*pi*k*n)/N);
        end
    end
%     stem(0:N-1, abs(y),'b');
%     grid
%     figure
%     stem(0:N-1, angle(y),'r');
%     grid

end