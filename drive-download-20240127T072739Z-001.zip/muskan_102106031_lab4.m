%% window function
clc 
clear all 
m = 25;
t = (0:1:m-1);
ah4 = ones(1,25);
figure
subplot(1,2,1)
stem(t, ah4);
xlabel('time');
ylabel('Amplitude'); 
title('Time response of window function');
legend('Muskan;102106031')

[h, w]=freqz (ah4, 1, 2048);
wn=w./(2*pi);
hn=abs (h)./max (abs (h));
subplot(1,2,2)
plot(wn,20.*log10(hn))
title('Frequency response of window function');
legend('Muskan;102106031')
xlabel('frequency')
ylabel('Magnitude')

%% for triangular function

clc 
clear all 
m = 25;
t = (0:1:m-1);
ah=0.54-0.46.*cos((2.*pi.*t)./(m));
ah4 = ones(1,25);
figure
subplot(1,2,1)
stem(t, ah,'b');
xlabel('time');
ylabel('Amplitude'); 
title('Time response of barlett window');
legend('Muskan;102106031')


[h, w]=freqz (ah, 1, 2048);
wn=w./(2*pi);
hn=abs (h)./max (abs (h));
subplot(1,2,2)
plot(wn,20.*log10(hn), 'r')
title('Frequency response of barlett window');
legend('Muskan;102106031')
xlabel('frequency')
ylabel('Magnitude')


