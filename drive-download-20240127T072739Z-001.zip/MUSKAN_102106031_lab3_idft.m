clc
clear all
x=input('enter the sequence');
N=input('enter the length of sequence');
t=dft1(x,N)
i_t = seqIDFT(t)

subplot(1,2,1)
stem(abs(t))
title('magnitude of dft')
xlabel('n')
ylabel('magnitude')
legend('muskan,102106031')
grid on

subplot(1,2,2)
stem(angle(t))
title('phase spectrum')
xlabel('n')
ylabel('phase')
legend('muskan,102106031')
grid on