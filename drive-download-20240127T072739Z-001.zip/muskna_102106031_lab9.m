clc
clear all
fc= input('Enter passband edge frequency: ')
fs= input('Enter sampling frequency: ')
n= input('enter order of filter: ')
[b,a]= butter(n,fc/(fs/2));

%%  analog filter
freqz(b,a,[],fs);
%% analog to digital conversion
[bz,az]= impinvar(b,a,fs);
fvtool(bz,az)
legend('dhruv,102106029')
title('butterworth lowpass prototype')
grid on