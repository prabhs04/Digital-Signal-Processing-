%% lab 1b generate square wave
clc
clear all
amplitude = 1000;
timeperiod = 0.1;
numcycles = 10;
oneperiod = amplitude*[ones(1,100),zeros(1,100)];
dt = timeperiod/numel(oneperiod);
fullwaveform = repmat(oneperiod,[1,numcycles]);
t = dt*(0:(numel(fullwaveform)-1));
plot(t,fullwaveform)
xlabel('time(seconds)');
ylabel('amplitude')
title('square wave with 10 cycles')
legend('muskan,102106031')
grid on 