%% 1 c to generate signal with user input freq,amplitude
clc
clear all
f1 = 120;
numcycles = 10;
duration = 1;
amplitude = 1;
fs = f1/60;
freqsinusoid = numcycles/60;
t = 1/fs:1/fs:duration*numcycles*1/freqsinusoid;
y = amplitude*sin(2*pi*freqsinusoid*t)
plot(t,y)
xlabel('time(seconds)')
ylabel('amplitude')
title('sinusoidal signal with 10 cycles')
legend('muskan,102106031')
grid on 

