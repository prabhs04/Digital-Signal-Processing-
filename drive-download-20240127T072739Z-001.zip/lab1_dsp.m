clc
clear all
% rectangular pulse
% t1 = -10:0.1:-0.5
% t2 = -0.5:0.1:0.5
% t3 = 0.5:0.1:10
% y1 = 0*t1
% y2 = 0*t2+1
% y3 = t3*0
% t = [t1,t2,t3]
% y = [y1,y2,y3]
% plot(t,y)

%unit impulse
% t1 = -10:1:0
% t2 = 0
% t3 = 0:1:10
% t = [t1,t2,t3]
% y1 = 0*t1
% y2 = 0*t2+1
% y3 = 0*t3
% y = [y1,y2,y3]
% plot(t,y)

%unit step
% t1 = -10:1:0
% t2 = 0:1:10
% t = [t1,t2]
% y1 = 0*t1
% y2 = 0*t2+1
% y = [y1,y2]
% subplot(2,2,1)
% plot(t,y)
% subplot(2,2,2)
% stem(t,y)

%square wave 
% t = linspace(-pi,2*pi,121);
% x = 1*square(2*t);
% subplot(2,2,3)
% plot(t/pi,x,'.-')%,t/pi,1.15*sin(2*t))
% xlabel('t / \pi')
% grid on
% t=-10:0.1:10;
% a=1;
% for i=1:2:201
%       if a==1
%          z(1,i)=0;
%          z(1,i+1)=0;
%     else 
%          z(1,i)=1;
%          z(1,i+1)=1;
%       end
%     a=a*(-1); 
% end
% subplot(2,2,3)
% plot(t,z)

% %SQUARE WAVE BY SIR 
% onePeriod = 1000 * [ones(1, 100), zeros(1, 100)];
% % 200 elements is supposed to be 0.1 seconds so find out delta t.
% dt = 0.1 / numel(onePeriod);
% % Define number of cycles.
% numCycles = 10;
% % Copy this period that many times.
% fullWaveForm = repmat(onePeriod, [1, numCycles]);
% % Make time axis from 0 to 1 second.
% t = dt * (0 : (numel(fullWaveForm) - 1));
% % Now plot it.
% plot(t, fullWaveForm, 'b-', 'LineWidth', 2);
% FontSize = 20;
% xlabel('Time (seconds)', 'FontSize', FontSize);
% ylabel('Amplitude', 'FontSize', FontSize);
% title('Square Wave With 10 Cycles', 'FontSize', FontSize);
% grid on;

%SIN WAVE BY SIR
% Make a sinusoid that oscillates between 0 and 0.1 with a period of 1 second.
% The sinusoid should be sampled at 2 ms and plotted for the first 10 seconds.
amplitude = 0.1;
period = 1.0;
% Time samples go from 0 to 10 seconds.
% Have 5000 of them so that the spacing is 2 milliseconds.
t = linspace(0, 10, 5000);
% Create y
y = amplitude * sin(2 * pi * t / period);
plot(t, y, 'b-', 'LineWidth', 2);
xlabel('t', 'FontSize', FontSize);
ylabel('y', 'FontSize', FontSize);
grid on;
% Set up figure properties:
% Enlarge figure to full screen.
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
% Get rid of tool bar and pulldown menus that are along top of figure.
set(gcf, 'Toolbar', 'none', 'Menu', 'none');
