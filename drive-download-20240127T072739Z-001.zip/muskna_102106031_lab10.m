clc
clear all
N = 51;
n = 0:N-1;
f1 = 0.15;
x1 = sin(2*pi*f1*n);
f2 = 0.1;
f3 = 0.3;
x4 = sin(2*pi*f2*n)+sin(2*pi*f3*n);
M = 4;
y1 = downsample(x1,M);
L1 = length(y1);
y4 = downsample(x4,M);
L4 = length(y4);
M=5;
y2 = upsample(x1,M);
L2 = length(y2);
y3 = upsample(x4,M);
L3 = length(y3);
subplot(3,2,1)
stem(0:N-1, x1(1:N));
xlabel('n')
ylabel('x1(n)')
title('Input Signal ')
legend('muskan,102106031')
grid on;
subplot(3,2,2)
stem(0:N-1,x4(1:N))
xlabel('n')
ylabel('x4(n)')
title('Sum of two sin signal')
legend('muskan,102106031')
grid on;
subplot(3,2,3)
stem(0:L1-1,y1(1:L1));
xlabel('n')
ylabel('y1(n)')
title('downsampling Input signal ')
legend('muskan,102106031')
grid on
subplot(3,2,4)
stem(0:L4-1,y4(1:L4));
xlabel('n')
ylabel('y4(n)')
title('downsampling Sum of two sin signal')
legend('muskan,102106031')
grid on;
subplot(3,2,5)
stem(0:L2-1, y2(1:L2));
xlabel('n')
ylabel('y1(n)')
title('Upsampling Input Signal ')
legend('muskan,102106031')
grid on;
subplot(3,2,6)
stem(0:L3-1,y3(1:L3))
xlabel('n')
ylabel('y4(n)')
title('Upsampling Sum of two sin signal')
legend('muskan,102106031')
grid on;